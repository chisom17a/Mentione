
document.getElementById("loginForm").addEventListener("submit", function(e) {
    e.preventDefault();
    const email = document.getElementById("loginEmail").value;
    const password = document.getElementById("loginPassword").value;

    if (email && password.length >= 6) {
        alert("Login was successful and you will be redirected in 3 seconds");
        setTimeout(() => {
            window.location.href = "dashboard.html";
        }, 3000);
    }
});
