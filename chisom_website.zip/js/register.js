
document.addEventListener("DOMContentLoaded", () => {
    const captcha = document.getElementById("captcha");
    const captchaInput = document.getElementById("captchaInput");
    const form = document.getElementById("registerForm");
    const password = document.getElementById("password");
    const repeatPassword = document.getElementById("repeatPassword");

    const generateCaptcha = () => {
        return Math.floor(10000 + Math.random() * 90000).toString();
    };

    const correctCaptcha = generateCaptcha();
    captcha.textContent = correctCaptcha;

    form.addEventListener("submit", (e) => {
        e.preventDefault();
        if (password.value !== repeatPassword.value) {
            alert("Passwords do not match.");
            return;
        }
        if (captchaInput.value !== correctCaptcha) {
            alert("CAPTCHA is incorrect.");
            return;
        }
        window.location.href = "login.html";
    });
});
